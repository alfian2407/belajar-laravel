<?php $__env->startSection('content'); ?>
<div class="container">
	<?php if(session('sukses')): ?>
		<div class="row alert alert-success" role="alert">
			<?php echo e(session('sukses')); ?>

		</div>
	<?php endif; ?>
	<div class="row">
		<div class="col-md-6">
			<div class="card mt-4">
				<div class="card-header bg-primary">
					<h2 class="text-center text-white"><?php echo e($judul); ?></h2>
				</div>
				<div class="card-body">
					<form action="update" method="POST">
			      		<?php echo e(csrf_field()); ?>

				        <div class="form-group">
				        	<label for="nama">Nama</label>
				    		<input name="nama" type="text" class="form-control" id="nama" value="<?php echo e($siswa->nama); ?>">
				  		</div>
						<div class="form-group">
							<label for="nis">NIS</label>
						    <input name="nis" type="text" class="form-control" id="nis" value="<?php echo e($siswa->nis); ?>">
						</div>
						<div class="form-group">
							<label for="jenis_kelamin">Pilih Jenis Kelamin</label>
						    <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
						    	<option value="L" <?php if($siswa->jenis_kelamin == 'L'): ?> selected <?php endif; ?>>Laki - Laki</option>
						    	<option value="P" <?php if($siswa->jenis_kelamin == 'P'): ?> selected <?php endif; ?>>Perempuan</option>
						    </select>
						</div>
						<div class="form-group">
							<label for="agama">Agama</label>
						    <input name="agama" type="text" class="form-control" id="agama" value="<?php echo e($siswa->agama); ?>">
						</div>
						<div class="form-group">
							<label for="alamat">Alamat</label>
						    <textarea name="alamat" class="form-control" id="alamat"><?php echo e($siswa->alamat); ?></textarea>
						</div>
				        <button type="submit" class="btn btn-outline-success">Update Data</button>
				    </form>
				</div>
			</div>
	    </div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\laravel\resources\views/siswa/edit.blade.php ENDPATH**/ ?>