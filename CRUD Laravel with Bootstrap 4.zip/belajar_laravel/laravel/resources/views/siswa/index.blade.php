@extends('layouts.master')

@section('content')
<div class="container mt-4">
	@if(session('sukses'))
		<div class="row alert alert-success alert-dismissible fade show" role="alert">
			{{session('sukses')}}
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    			<span aria-hidden="true">&times;</span>
  			</button>
		</div>
	@endif
	<div class="row">
		<div class="col-md-12">
			<h2 class="text-center">Data Siswa</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<button type="button" class="btn btn-outline-primary mb-3" data-toggle="modal" data-target="#exampleModal">Tambah Data Siswa</button>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<table class="table table-hover">
				<tr class="bg-primary text-white">
					<th class="text-center">Nama</th>
					<th>NIS</th>
					<th>Jenis Kelamin</th>
					<th>Agama</th>
					<th class="text-center">Alamat</th>
					<th class="text-center">Aksi</th>
				</tr>
				@foreach($data_siswa as $siswa)
				<tr>
					<td>{{$siswa->nama}}</td>
					<td>{{$siswa->nis}}</td>
					<td class="text-center">{{$siswa->jenis_kelamin}}</td>
					<td>{{$siswa->agama}}</td>
					<td>{{$siswa->alamat}}</td>
					<td class="text-center">
						<a href="siswa/{{$siswa->id}}/edit" class="btn btn-outline-success btn-sm">Edit</a>
						<a href="siswa/{{$siswa->id}}/delete" onclick="return confirm('Yakin Data Akan Dihapus ? ')" class="btn btn-outline-danger btn-sm">Delete</a>
					</td>
				</tr>
				@endforeach
			</table>	
		</div>	
	</div>
</div>
	
	
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<form action="siswa/create" method="POST">
      		{{csrf_field()}}
	        <div class="form-group">
	        	<label for="nama">Nama</label>
	    		<input name="nama" type="text" class="form-control" id="nama">
	  		</div>
			<div class="form-group">
				<label for="nis">NIS</label>
			    <input name="nis" type="text" class="form-control" id="nis">
			</div>
			<div class="form-group">
				<label for="jenis_kelamin">Pilih Jenis Kelamin</label>
			    <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
			    	<option value="L">Laki - Laki</option>
			    	<option value="P">Perempuan</option>
			    </select>
			</div>
			<div class="form-group">
				<label for="agama">Agama</label>
			    <input name="agama" type="text" class="form-control" id="agama">
			</div>
			<div class="form-group">
				<label for="alamat">Alamat</label>
			    <textarea name="alamat" class="form-control" id="alamat"></textarea>
			</div>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Save changes</button>
	      </div>
	    </form>
    </div>
  </div>
</div>

@endsection