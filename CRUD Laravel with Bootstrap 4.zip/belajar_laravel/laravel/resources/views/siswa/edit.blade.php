@extends('layouts.master')

@section('content')
<div class="container">
	@if(session('sukses'))
		<div class="row alert alert-success" role="alert">
			{{session('sukses')}}
		</div>
	@endif
	<div class="row">
		<div class="col-md-6">
			<div class="card mt-4">
				<div class="card-header bg-primary">
					<h2 class="text-center text-white">{{$judul}}</h2>
				</div>
				<div class="card-body">
					<form action="update" method="POST">
			      		{{csrf_field()}}
				        <div class="form-group">
				        	<label for="nama">Nama</label>
				    		<input name="nama" type="text" class="form-control" id="nama" value="{{$siswa->nama}}">
				  		</div>
						<div class="form-group">
							<label for="nis">NIS</label>
						    <input name="nis" type="text" class="form-control" id="nis" value="{{$siswa->nis}}">
						</div>
						<div class="form-group">
							<label for="jenis_kelamin">Pilih Jenis Kelamin</label>
						    <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
						    	<option value="L" @if($siswa->jenis_kelamin == 'L') selected @endif>Laki - Laki</option>
						    	<option value="P" @if($siswa->jenis_kelamin == 'P') selected @endif>Perempuan</option>
						    </select>
						</div>
						<div class="form-group">
							<label for="agama">Agama</label>
						    <input name="agama" type="text" class="form-control" id="agama" value="{{$siswa->agama}}">
						</div>
						<div class="form-group">
							<label for="alamat">Alamat</label>
						    <textarea name="alamat" class="form-control" id="alamat">{{$siswa->alamat}}</textarea>
						</div>
				        <button type="submit" class="btn btn-outline-success">Update Data</button>
				    </form>
				</div>
			</div>
	    </div>
	</div>
</div>

@endsection